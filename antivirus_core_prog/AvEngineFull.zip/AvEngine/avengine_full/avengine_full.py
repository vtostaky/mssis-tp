#!/usr/bin/python
'''
Simple Antivirus Engine
'''

import os
import sys
import glob
import json
import mmap
import time
import struct

from argparse import ArgumentParser
from UserDict import UserDict

import pefile
from utils import cprinter

try:
    import memscan
except:
    pass


def crc_block(data):
    return reduce(lambda x, y: (((x << 7) | (x >> 25)) + ord(y)) & 0xFFFFFFFF, data, 0)


VIRREC_OFFSET = 0
VIRREC_ENTRY  = 1
VIRREC_MEMORY = 2


#virusbase = [
#   (VIRREC_OFFSET, "File.BackDoor.Tinyshell",   0xACE, 0x016a066a, 0x80, 0xBC1FB2DC, -1, None),
#   (VIRREC_OFFSET, "File.BackDoor.Tinyshell",   0x100, 0xC86E939, 0x40, 0x13EF8D73, -1, null],
#   (VIRREC_ENTRY,  "VirusOnEntryPoint"        , 0, 0x000000e8, 0x60, 0x0695D584, -1, None),
#   (VIRREC_ENTRY,  "VirusOnEmulatedEntryPoint", 0x43a, 0xffdc75ff, 0x47, 0x6B560B6A, -1, None),
#   (VIRREC_MEMORY, "Memory.BackDoor.Tinyshell", 0xACE, 0x016a066a, 0x80, 0xBC1FB2DC, -1, None),
#]


class VirRecord(UserDict):
    def __init__(self, rec):
        UserDict.__init__(self)
        self.data['type'], \
        self.data['virname'], \
        self.data['offset'], \
        self.data['check'], \
        self.data['crclen'], \
        self.data['crc'], \
        self.data['patchlen'], \
        self.data['patchdata'] = rec


class AvEngine(object):
    RESULT_CLEAN    = 0
    RESULT_INFECTED = 1
    RESULT_ERROR    = 2

    def __init__(self, virusbase_dir):
        self.virusbase_dir = virusbase_dir
        self.virus_records = []
        self.cur_map = None
        self.file_size = 0
        self.pe = pefile.PeFileParser()

    # next two methods for `with` statement
    def __enter__(self):
        self.load_virusbases()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            from traceback import format_exception
            cprinter('\n[red]Exception in AvEngine:[/red]\n')
            sys.stdout.write('\n'.join(format_exception(exc_type, exc_val, exc_tb)))
        if self.cur_map is not None:
            self.cur_map.close()
        return True

    def load_virusbases(self):
        for virbase in glob.iglob(os.path.join(self.virusbase_dir, '*.vdb')):
            with open(virbase, 'rb') as f:
                self.virus_records.extend(json.load(f))
        
        # split virus records by type
        self.offset_virus_records = filter(lambda rec: rec[0] == VIRREC_OFFSET, self.virus_records)
        self.entry_virus_records = filter(lambda rec: rec[0] == VIRREC_ENTRY, self.virus_records)
        self.memory_virus_records = filter(lambda rec: rec[0] == VIRREC_MEMORY, self.virus_records)

        # convert virus records to objects
        self.offset_virus_records = [VirRecord(x) for x in self.offset_virus_records]
        self.entry_virus_records =  [VirRecord(x) for x in self.entry_virus_records]
        self.memory_virus_records = [VirRecord(x) for x in self.memory_virus_records]
        
        cprinter('[white]loaded {} records[/white]\n', len(self.virus_records))

    def scanmem_page(self, pid, addr, data):
        for record in self.memory_virus_records:
            offset = record['offset']
            check, = struct.unpack_from("<L", data, offset)
            if check == record['check']:
                crc = crc_block(data[offset : offset + record['crclen']])
                if crc == record['crc']:
                    cprinter("[red]{} (at {:08X})[/red]".format(record['virname'], addr+record['offset']))
                    if record['patchlen'] != -1:
                        poffset, pbyte = record['patchdata']
                        data[poffset] = chr(pbyte)
                        memscan.patch_data(pid, addr, data)
                        return True
                    else:
                        memscan.kill_process(pid)
                        return True
        return False

    def scanmem(self):
        memscan.scanmemory(self.scanmem_page)

    def mapfile(self, fname, size):
        if self.cur_map:
            self.cur_map.close()
            self.cur_map = None
        try:
            with open(fname, 'rb') as f:
                self.cur_map = mmap.mmap(f.fileno(), 0, access=mmap.ACCESS_READ)
        except:
            self.cur_map = None
        return self.cur_map is not None

    def check_crc(self, offset, record):
        data_offset = offset + record['offset']
        if data_offset + record['crclen'] < self.file_size:
            # extract check 'dword'
            check, = struct.unpack_from("<L", self.cur_map, data_offset)
            if check == record['check']:
                # calculate crc
                crc = crc_block(self.cur_map[data_offset : data_offset + record['crclen']])
                if crc == record['crc']:
                    return True
        return False

    def check_file(self):
        if not self.cur_map:
            return self.RESULT_ERROR, '???'

        # Scan "DATA" section
        offset = self.pe.get_datasect_offset()
        if offset and offset < self.file_size:
            for rec in self.offset_virus_records:
                if self.check_crc(offset, rec):
                    return self.RESULT_INFECTED, rec['virname']

        # Scan "EASY" section
        ep_rva = self.pe.get_ep_rva()               # rva offset of entry point
        ep_offset = self.pe.rva_to_offset(ep_rva)   # file offset of entry point
        
        emulate = True
        while emulate and (None not in (ep_rva, ep_offset)):
            for rec in self.entry_virus_records:
                if self.check_crc(ep_offset, rec):
                    return self.RESULT_INFECTED, rec['virname']
            
            emulate = False
            # extract known opcodes
            #   * 0x60          pushd 
            #   * 0xE8 XXXXXXX  call XXXXXXX
            if self.file_size - ep_offset > 6:
                opcodes, addr = struct.unpack_from("<HL", self.cur_map, ep_offset)
                if opcodes == 0xE860:
                    # emulate
                    ep_rva += 6 + addr
                    ep_offset = self.pe.rva_to_offset(ep_rva)
                    # swith emulator on
                    emulate = True

        return self.RESULT_CLEAN, ''

    def scanfile(self, fname):
        result = self.RESULT_CLEAN
        virus_name = ''
        self.file_size = 0
        cprinter('[white]{}[/white] - ', fname)
        try:
            self.file_size = file_size = os.path.getsize(fname)
            if file_size:
                if self.mapfile(fname, file_size):
                    if self.pe.parse(self.cur_map, file_size):
                        result, virus_name = self.check_file()
                else:
                    result = self.RESULT_ERROR
        except OSError:
            if self.cur_map:
                self.cur_map.close()
            result = self.RESULT_ERROR
        
        if result == self.RESULT_ERROR:
            cprinter('[red]Error[/red]\n')
        elif result == self.RESULT_CLEAN:
            cprinter('[green]Clean[/green]\n')
        elif result == self.RESULT_INFECTED:
            cprinter('[cyan]{}[/cyan] - [red]Infected[/red]\n', virus_name)

    def scanfiles(self, directory):
        for root, dirs, files in os.walk(directory):
            for fname in files:
                self.scanfile(os.path.join(root, fname))


def main():
    start_time = time.time()
    
    parser = ArgumentParser(description=__doc__, prog=os.path.basename(__file__))
    parser.add_argument('-m', '--memoryscan', action='store_true', help='Force memory scanning')
    parser.add_argument('-v', '--virbasedir', default='.', help='Directory where virus bases located')
    parser.add_argument('dirs', nargs='*', help='Directories to scan')
    args = parser.parse_args()

    with AvEngine(args.virbasedir) as engine:
        if args.memoryscan:
            if 'memscan' in sys.modules:
                cprinter('[yellow]Scanning memory[/yellow]\n')
                engine.scanmem()
            else:
                cprinter('[red]Memory scanning is available only on Windows[/red]\n')
        cprinter('[yellow]Scanning files[/yellow]\n')
        if not args.dirs:
            args.dirs.append('.')
        for directory in args.dirs:
            engine.scanfiles(directory)
    
    cprinter('[white]Scanning done in {:.1f} seconds[/white]\n', time.time() - start_time)
    return 0


if __name__ == '__main__':
    sys.exit(main())
