'''
Memory scanning
'''

__all__ = ['scanmemory', 'patch_data', 'kill_process']

import sys
import struct
import ctypes

try:
    has_wintypes = True
    from ctypes import wintypes
except:
    has_wintypes = False

from utils import cprinter


TOKEN_ADJUST_PRIVILEGES=0x0020
TOKEN_QUERY=0x0008

# Windows API
CreateToolhelp32Snapshot  = ctypes.windll.kernel32.CreateToolhelp32Snapshot
Process32First            = ctypes.windll.kernel32.Process32First
Process32Next             = ctypes.windll.kernel32.Process32Next
GetCurrentProcessId       = ctypes.windll.kernel32.GetCurrentProcessId
OpenProcess               = ctypes.windll.kernel32.OpenProcess
CloseHandle               = ctypes.windll.kernel32.CloseHandle
VirtualQueryEx            = ctypes.windll.kernel32.VirtualQueryEx
GetSystemInfo             = ctypes.windll.kernel32.GetSystemInfo
WriteProcessMemory        = ctypes.windll.kernel32.WriteProcessMemory
ReadProcessMemory         = ctypes.windll.kernel32.ReadProcessMemory
TerminateProcess          = ctypes.windll.kernel32.TerminateProcess
GetLastError              = ctypes.windll.kernel32.GetLastError

# const
TH32CS_SNAPPROCESS        = 0x00000002
INVALID_HANDLE_VALUE      = -1
SE_DEBUG_PRIVILEGE        = 0x14
PROCESS_QUERY_INFORMATION = 0x400
PROCESS_VM_OPERATION      = 0x08
PROCESS_VM_READ           = 0x10
PROCESS_VM_WRITE          = 0x20
PROCESS_TERMINATE         = 0x01

MEM_COMMIT                = 0x1000
PAGE_NOACCESS             = 0x01


FALSE = wintypes.BOOL(0)
TRUE  = wintypes.BOOL(1)

#PROCESSENTRY32 Structure

class PROCESSENTRY32(ctypes.Structure):
    _fields_ = [
        ("dwSize",              ctypes.c_ulong),
        ("cntUsage",            ctypes.c_ulong),
        ("th32ProcessID",       ctypes.c_ulong),
        ("th32DefaultHeapID",   ctypes.c_void_p),
        ("th32ModuleID",        ctypes.c_ulong),
        ("cntThreads",          ctypes.c_ulong),
        ("th32ParentProcessID", ctypes.c_ulong),
        ("pcPriClassBase",      ctypes.c_ulong),
        ("dwFlags",             ctypes.c_ulong),
        ("szExeFile",           ctypes.c_char * 260)]

class MEMORY_BASIC_INFORMATION(ctypes.Structure):
    _fields_ = [
        ("BaseAddress",         ctypes.c_void_p),
        ("AllocationBase",      ctypes.c_void_p),
        ("AllocationProtect",   ctypes.c_ulong),
        ("RegionSize",          ctypes.c_size_t),
        ("State",               ctypes.c_ulong),
        ("Protect",             ctypes.c_ulong),
        ("Type",                ctypes.c_ulong)]

class SYSTEM_INFO(ctypes.Structure):
    _fields_ = [
        ("dwOemId",                     ctypes.c_ulong),
        ("dwPageSize",                  ctypes.c_ulong),
        ("lpMinimumApplicationAddress", ctypes.c_void_p),
        ("lpMaximumApplicationAddress", ctypes.c_void_p),
        ("dwActiveProcessorMask",       ctypes.c_size_t),
        ("dwNumberOfProcessors",        ctypes.c_ulong),
        ("dwProcessorType",             ctypes.c_ulong),
        ("dwAllocationGranularity",     ctypes.c_ulong),
        ("wProcessorLevel",             ctypes.c_ushort),
        ("wProcessorRevision",          ctypes.c_ushort)]


def get_debug_privs():
    dwTmp = wintypes.DWORD()
    old   = wintypes.BOOL()
    return ctypes.windll.Ntdll.RtlAdjustPrivilege(SE_DEBUG_PRIVILEGE, TRUE, FALSE, ctypes.pointer(old))


# get debugging privileges once our engine has started
get_debug_privs()


def scanmemory(fncallback):
    pe = PROCESSENTRY32()
    mbi = MEMORY_BASIC_INFORMATION()
    si = SYSTEM_INFO()

    GetSystemInfo(ctypes.byref(si))

    hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    if hSnap != INVALID_HANDLE_VALUE:
        pe.dwSize = ctypes.sizeof(PROCESSENTRY32)
        page_data = ctypes.create_string_buffer(si.dwPageSize)

        status = Process32First(hSnap, ctypes.byref(pe))
        while status:
            detected = False
            hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_OPERATION | PROCESS_VM_READ | PROCESS_VM_WRITE, 
                FALSE, pe.th32ProcessID)
            if hProcess != INVALID_HANDLE_VALUE:
                cprinter('[white]({:04X}) {} [/white]'.format(pe.th32ProcessID, pe.szExeFile))
                scan_addr = 0
                while VirtualQueryEx(hProcess, wintypes.DWORD(scan_addr), ctypes.byref(mbi), ctypes.sizeof(mbi)):
                    scan_addr = scan_addr + mbi.RegionSize
                    if mbi.State == MEM_COMMIT and mbi.Protect != PAGE_NOACCESS:
                        in_region_offset = 0
                        while in_region_offset < mbi.RegionSize:
                            if fncallback:
                                if ReadProcessMemory(hProcess, scan_addr + in_region_offset, page_data, si.dwPageSize, None):
                                    if fncallback(pe.th32ProcessID, scan_addr + in_region_offset, page_data):
                                        detected = True

                            in_region_offset = in_region_offset + si.dwPageSize

                    if scan_addr > si.lpMaximumApplicationAddress:
                        break
                
                CloseHandle(hProcess)

            if detected:
                cprinter('\n')
            else:
                cprinter(' [green]Clean[/green]\n');

            status = Process32Next(hSnap, ctypes.byref(pe))
    
        CloseHandle(hSnap)

def patch_data(pid, addr, data):
    hProcess = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_OPERATION | PROCESS_VM_READ | PROCESS_VM_WRITE, FALSE, pid)
    if hProcess != INVALID_HANDLE_VALUE:
        if WriteProcessMemory(hProcess, addr, data, len(data), None):
            cprinter(" [green]- patched[/green] ")
        else:
            cprinter(" [red]- error patching - {}[/red] ", GetLastError())
        CloseHandle(hProcess)


def kill_process(pid):
    hProcess = OpenProcess(PROCESS_TERMINATE, FALSE, pid)
    if hProcess != INVALID_HANDLE_VALUE:
        if TerminateProcess(hProcess, 0):
            cprinter(" [green]- killed[/green] ")
        else:
            cprinter(" [red]- cannot kill - {}[/red] ", GetLastError())
        CloseHandle(hProcess)
